

Za pregled je potrebno instalirati XAMPP i sve datoteke premjestiti u  "C:\xampp\htdocs".

Potrebno je importati bazu: baza.sql

